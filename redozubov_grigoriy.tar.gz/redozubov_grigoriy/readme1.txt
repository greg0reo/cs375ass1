You compile the program by typing "make" in the terminal.
Alternatively, you can type in "make program1".
Then, you run the program by writing "./program1 <filex.txt> <filey.txt> <output>"

The program uses a 2D vector to store the "memos".

This is the fastest of the three programs we wrote.
The larger the input, the more faster this program's runtime is than the other programs.

I did not use any classes in this program.
