You compile the program by typing "make" in the terminal.
Alternatively, you can type in "make program2".
Then, you run the program by writing "./program2 <filex.txt> <filey.txt> <output>"

The program does not use any data structures.

This program works ok with small input sizes. However, with greater input sizes, the program falls behind very quickly. Due to computing each subroutine, this program uses up way more computation time than necessary, as can be seen with program 3.

I did not use any classes in this program.
