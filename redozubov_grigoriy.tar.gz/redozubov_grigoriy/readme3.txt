You compile the program by typing "make" in the terminal.
Alternatively, you can type in "make program3".
Then, you run the program by writing "./program3 <filex.txt> <filey.txt> <output>"

The program uses a 2D vector to store the "memos". This vector is filled in top-down.

This is the second fastest program.
It can compete with program1 for small input sizes, such as the ones used in this project, but with higher inputs, it begins to lag behind

I did not use any classes in this program.
